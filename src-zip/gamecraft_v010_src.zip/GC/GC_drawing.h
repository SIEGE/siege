#ifndef _GC_drawing_h
#define _GC_drawing_h

namespace GC
{
    // all this char crap might be changed to Uint8 someday...
    void DrawSprite(long sprite,int x = 0,int y = 0,short angle=0,char alpha=0xFF)
    {
        SDL_Rect rect;
        rect.x = x-gSpriteArray[sprite].xorigin;
        rect.w = gSpriteArray[sprite].surface->w;
        rect.y = y-gSpriteArray[sprite].yorigin;
        rect.h = gSpriteArray[sprite].surface->h;
        SDL_BlitSurface(gSpriteArray[sprite].surface, 0, gpScreen, &rect);
    }

    void DrawPixel(int x,int y,char color,char alpha=0xFF)
    {
        // draw a pixel...
    }

    void DrawLine(int x1,int y1,int x2,int y2,char color[1],char alpha[1]=(char*)0xFFFF)
    {
        // draw a line...
    }

    void DrawTriangle(int x1,int y1,int x2,int y2,int x3,int y3,char color[2],char alpha[2]=(char*)0xFFFFFF,bool fill=1)
    {
        // draw a triangle...
    }

    void DrawRectangle(int x1,int y1,int x2,int y2,char color[3],char alpha[3]=(char*)0xFFFFFFFF,bool fill=1)
    {
        // draw a rectangle...
    }
}

#endif
