#ifndef _GC_constants_h
#define _GC_constants_h

// SCREEN
#define WIDTH 640
#define HEIGHT 480
#define BPP 16

// COLORS
#define AQUA    0x00FFFF
#define BLACK   0x000000
#define BLUE    0x0000FF
#define FUCHSIA 0xFF00FF
#define GRAY    0x808080
#define GREEN   0x008000
#define LIME    0x00FF00
#define MAROON  0x800000
#define NAVY    0x000080
#define OLIVE   0x808000
#define PURPLE  0x800080
#define RED     0xFF0000
#define SILVER  0xC0C0C0
#define TEAL    0x008080
#define WHITE   0xFFFFFF
#define YELLOW  0xFFFF00

#endif
